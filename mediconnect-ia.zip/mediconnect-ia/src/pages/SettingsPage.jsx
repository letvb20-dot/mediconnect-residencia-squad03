import { useState } from 'react'

import { settingsRepository } from '../repositories/settingsRepository.js'
import { getNotificationPrefs, saveNotificationPrefs } from '../repositories/notificationRepository.js'
import { getStoredTheme, setStoredTheme } from '../utils/theme.js'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.jsx'
import { Switch } from '../components/ui/switch.jsx'

import { useAccessibility } from '../contexts/accessibilityContext.js'

const cardClass = 'rounded-2xl border border-border-default-v2 bg-surface-card shadow-card'
const inputClass =
  'h-10 rounded-xl border border-border-default-v2 bg-surface-inset px-3 text-sm text-text-body outline-none transition focus:border-accent-primary focus:ring-2 focus:ring-accent-primary/20'

export function SettingsPage() {
  const sections = settingsRepository.getSections()
  const [activeSection, setActiveSection] = useState('aparencia')

  return (
    <div className="mx-auto max-w-5xl">
      <header className="mb-8">
        <h1 className="text-[32px] font-bold leading-8 tracking-[-0.02em] text-text-heading">Configurações</h1>
        <p className="mt-1 text-sm text-text-muted-v2">Gerencie preferências, segurança e integrações do MediConnect</p>
      </header>

      <div className="flex flex-col gap-6 lg:flex-row">
        <nav className="lg:w-64" aria-label="Seções de configuração">
          <div className={`${cardClass} flex flex-col gap-1 p-2`}>
            {sections.map((item) => (
              <button
                className={`flex items-center gap-3 rounded-xl px-3 py-3 text-left transition ${
                  activeSection === item.id
                    ? 'bg-accent-primary/10 text-accent-primary'
                    : 'text-text-muted-v2 hover:bg-surface-card-hover hover:text-text-body'
                }`}
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                type="button"
              >
                <SettingsIcon className="size-4 shrink-0" name={item.icon} />
                <span className="min-w-0">
                  <span className="block text-sm font-semibold leading-none">{item.label}</span>
                  <span className="mt-1 block truncate text-[11px] opacity-70">{item.description}</span>
                </span>
              </button>
            ))}
          </div>
        </nav>

        <section className={`${cardClass} min-w-0 flex-1 p-6 lg:p-8`}>
          {activeSection === 'aparencia' ? <AppearanceSection /> : null}
          {activeSection === 'notificacoes' ? <NotificationsSection /> : null}
          {activeSection === 'conta' ? <AccountSection /> : null}
          {activeSection === 'integracoes' ? <IntegrationsSection /> : null}
          {activeSection === 'privacidade' ? <PrivacySection /> : null}
          {activeSection === 'dados' ? <DataSection /> : null}
        </section>
      </div>
    </div>
  )
}

function AppearanceSection() {
  const [theme, setTheme] = useState(() => getStoredTheme())
  const { ui, updateUi, toggleHighContrast, isHighContrast } = useAccessibility()

  function handleThemeChange(nextTheme) {
    setTheme(setStoredTheme(nextTheme))
  }

  return (
    <SectionFrame description="Personalize a interface do MediConnect." title="Aparência e Acessibilidade">
      <div className="mb-8">
        <p className="mb-4 text-sm font-semibold text-text-body">Tema da interface</p>
        <div className="grid max-w-xl gap-4 sm:grid-cols-2">
          {[
            { id: 'dark', label: 'Escuro', preview: 'bg-[#0a0a0a]' },
            { id: 'light', label: 'Claro', preview: 'bg-[#f4f7fb]' },
          ].map((item) => (
            <button
              className={`rounded-2xl border-2 p-4 text-left transition ${
                theme === item.id
                  ? item.id === 'dark'
                    ? 'border-border-strong bg-surface-inset shadow-md shadow-black/30'
                    : 'border-accent-primary bg-accent-primary/5 shadow-md shadow-accent-primary/20'
                  : 'border-border-default-v2 bg-surface-card hover:border-border-strong'
              }`}
              key={item.id}
              onClick={() => handleThemeChange(item.id)}
              type="button"
            >
              <span className={`settings-theme-preview ${item.id === 'dark' ? 'settings-theme-preview-dark' : 'settings-theme-preview-light'} mb-3 flex h-20 flex-col gap-1.5 overflow-hidden rounded-xl border border-border-default-v2 p-2 ${item.preview}`}>
                <span className={`settings-theme-preview-bar h-2.5 rounded ${item.id === 'dark' ? 'bg-surface-card' : 'bg-white'}`} />
                <span className="flex flex-1 gap-1">
                  <span className={`settings-theme-preview-side w-8 rounded ${item.id === 'dark' ? 'bg-surface-inset' : 'bg-white'}`} />
                  <span className="flex flex-1 flex-col justify-center gap-1">
                    <span className={`settings-theme-preview-line h-1.5 w-3/4 rounded-full ${item.id === 'dark' ? 'bg-border-strong' : 'bg-[#dde8f7]'}`} />
                    <span className={`settings-theme-preview-line h-1.5 w-1/2 rounded-full ${item.id === 'dark' ? 'bg-surface-card-hover' : 'bg-[#dde8f7]'}`} />
                  </span>
                </span>
              </span>
              <span className="flex items-center justify-between">
                <span className="text-sm font-semibold text-text-body">{item.label}</span>
                {theme === item.id ? <span className="grid size-5 place-items-center rounded-full bg-accent-primary text-[11px] text-white">✓</span> : null}
              </span>
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-text-muted-v2">A preferência de tema é salva localmente.</p>
      </div>

      <SettingsGroup>
        <ToggleRow checked={ui.animations} description="Transições suaves entre telas e componentes" label="Animações de interface" onChange={(value) => updateUi('animations', value)} />
        <ToggleRow checked={isHighContrast} description="Aumenta o contraste dos elementos para melhor acessibilidade" label="Modo de alto contraste" onChange={toggleHighContrast} />
        
        <SettingRow description="Define o tamanho base da interface" label="Escala Tipográfica">
          <div className="w-48">
            <Select value={ui.typographicScale} onValueChange={(val) => updateUi('typographicScale', val)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tamanho" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sm">Pequena (14px)</SelectItem>
                <SelectItem value="standard">Padrão (16px)</SelectItem>
                <SelectItem value="lg">Grande (18px)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </SettingRow>

        <SettingRow description="Idioma de exibição do sistema" label="Idioma do sistema">
          <div className="w-48">
            <Select value={ui.language} onValueChange={(val) => updateUi('language', val)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o idioma" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pt-br">Português (BR)</SelectItem>
                <SelectItem value="en-us">English (US)</SelectItem>
                <SelectItem value="es">Español</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </SettingRow>
      </SettingsGroup>
    </SectionFrame>
  )
}

function SkeletonToggleRow() {
  return (
    <div className="flex items-center justify-between gap-6 border-b border-[var(--border-default)] py-4 last:border-0">
      <div className="min-w-0 flex-1 pr-4 space-y-2">
        <div className="h-4 w-32 animate-pulse rounded bg-surface-card-hover"></div>
        <div className="h-3 w-64 animate-pulse rounded bg-surface-card-hover"></div>
      </div>
      <div className="shrink-0">
        <div className="h-6 w-11 animate-pulse rounded-full bg-surface-card-hover"></div>
      </div>
    </div>
  )
}

function NotificationsSection() {
  const [prefs, setPrefs] = useState(() => getNotificationPrefs())
  const isLoading = false

  function handleToggle(key, newValue) {
    const previous = { ...prefs }
    const next = { ...prefs, [key]: newValue }

    // Atualização otimista da UI
    setPrefs(next)

    try {
      saveNotificationPrefs(next)
      window.dispatchEvent(new CustomEvent('app:show_toast', {
        detail: {
          title: 'Preferência atualizada',
          description: 'Sua configuração de notificação foi salva.',
          type: 'success'
        }
      }))
    } catch {
      // Reversão em caso de falha (ex.: storage indisponível)
      setPrefs(previous)
      window.dispatchEvent(new CustomEvent('app:show_toast', {
        detail: {
          title: 'Erro ao salvar',
          description: 'Não foi possível salvar sua preferência. Tente novamente.',
          type: 'error'
        }
      }))
    }
  }

  return (
    <SectionFrame description="Escolha quais eventos aparecem no sino de notificações." title="Notificações">
      <SettingsGroup>
        {isLoading || !prefs ? (
          <>
            <SkeletonToggleRow />
            <SkeletonToggleRow />
            <SkeletonToggleRow />
            <SkeletonToggleRow />
          </>
        ) : (
          <>
            <ToggleRow 
              checked={prefs.notificacoes_agenda} 
              description="Marcações, alterações e cancelamentos de consulta" 
              label="Agenda" 
              onChange={(v) => handleToggle('notificacoes_agenda', v)} 
            />
            <ToggleRow 
              checked={prefs.notificacoes_comunicacao} 
              description="Mensagens SMS, Email e WhatsApp de pacientes" 
              label="Comunicação" 
              onChange={(v) => handleToggle('notificacoes_comunicacao', v)} 
            />
            <ToggleRow 
              checked={prefs.notificacoes_prontuario} 
              description="Criação e edição de prontuários" 
              label="Prontuário" 
              onChange={(v) => handleToggle('notificacoes_prontuario', v)} 
            />
            <ToggleRow 
              checked={prefs.notificacoes_relatorios} 
              description="Criação e edição de relatórios" 
              label="Relatórios" 
              onChange={(v) => handleToggle('notificacoes_relatorios', v)} 
            />
          </>
        )}
      </SettingsGroup>
    </SectionFrame>
  )
}

function AccountSection() {
  return (
    <SectionFrame description="Atalhos de conta do usuário logado." title="Conta & Perfil">
      <SettingsGroup>
        <SettingRow description="Nome, telefone, foto e unidade padrão" label="Dados do perfil">
          <a className="h-9 rounded-sm border border-border-default-v2 bg-surface-card-hover px-3 py-2 text-sm font-semibold text-text-body" href="/perfil">
            Abrir perfil
          </a>
        </SettingRow>
        <SettingRow description="Preferências locais desta sessão" label="Preferências">
          <span className="text-sm text-text-muted-v2">Ativas</span>
        </SettingRow>
      </SettingsGroup>
    </SectionFrame>
  )
}

function IntegrationsSection() {
  return (
    <SectionFrame description="Configure integrações externas usadas pela operação." title="Integrações">
      <div className="grid gap-4 md:grid-cols-2">
        {[
          ['WhatsApp', 'Envio de mensagens para pacientes'],
          ['E-mail', 'Envio de PDFs e comunicados'],
          ['SMS', 'Lembretes transacionais'],
          ['Armazenamento', 'Avatares e documentos'],
        ].map(([title, description]) => (
          <div className="rounded-xl border border-border-default-v2 bg-surface-inset p-4" key={title}>
            <p className="text-sm font-semibold text-text-heading">{title}</p>
            <p className="mt-1 text-xs leading-5 text-text-muted-v2">{description}</p>
            <span className="mt-3 inline-flex rounded bg-emerald-500/20 px-2 py-1 text-xs font-bold text-emerald-400">Disponível</span>
          </div>
        ))}
      </div>
    </SectionFrame>
  )
}

function PrivacySection() {
  const [twoFactor, setTwoFactor] = useState(false)
  const [audit, setAudit] = useState(true)
  const [anonymous, setAnonymous] = useState(false)

  return (
    <SectionFrame description="Gerencie conformidade com a Lei Geral de Proteção de Dados." title="Privacidade & LGPD">
      <div className="mb-6 flex gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4">
        <SettingsIcon className="mt-0.5 size-5 shrink-0 text-amber-400" name="alert" />
        <div>
          <p className="text-sm font-semibold text-amber-400">Conformidade LGPD ativa</p>
          <p className="mt-1 text-xs leading-5 text-text-muted-v2">Dados de pacientes são tratados com finalidade legítima e armazenados com segurança.</p>
        </div>
      </div>

      <Subsection title="Segurança de acesso">
        <ToggleRow checked={twoFactor} description="Adiciona uma camada extra de segurança ao login" label="Autenticação de dois fatores (2FA)" onChange={setTwoFactor} />
        <SettingRow description="Desconectar automaticamente após inatividade" label="Tempo de sessão">
          <select className={inputClass} defaultValue="30">
            <option value="30">30 minutos</option>
            <option value="60">1 hora</option>
            <option value="240">4 horas</option>
          </select>
        </SettingRow>
        <ToggleRow checked={audit} description="Registrar todas as ações realizadas no sistema" label="Log de auditoria" onChange={setAudit} />
      </Subsection>

      <Subsection title="Dados dos pacientes">
        <ToggleRow checked={anonymous} description="Ocultar dados pessoais identificáveis nos relatórios exportados" label="Anonimizar em relatórios" onChange={setAnonymous} />
        <SettingRow description="Período de armazenamento de dados inativos" label="Retenção de dados">
          <select className={inputClass} defaultValue="5">
            <option value="1">1 ano</option>
            <option value="3">3 anos</option>
            <option value="5">5 anos (padrão)</option>
            <option value="10">10 anos</option>
          </select>
        </SettingRow>
        <SettingRow description="Gerar relatório completo para atender solicitação de titular" label="Exportar dados do paciente">
          <button className="h-9 rounded-sm border border-border-default-v2 bg-surface-card-hover px-3 text-sm font-semibold text-text-body" type="button">Exportar</button>
        </SettingRow>
      </Subsection>
    </SectionFrame>
  )
}

function DataSection() {
  return (
    <SectionFrame description="Exporte, importe e gerencie backups do sistema." title="Dados & Backup">
      <Subsection title="Exportação de dados">
        <div className="grid gap-4 sm:grid-cols-2">
          {[
            ['Pacientes (CSV)', 'Lista completa com dados cadastrais'],
            ['Prontuários (PDF)', 'Registros médicos do período'],
            ['Relatório geral (PDF)', 'Dashboard executivo completo'],
          ].map(([label, desc]) => (
            <button className="flex items-center gap-3 rounded-xl border border-border-default-v2 bg-surface-inset p-4 text-left transition hover:border-accent-primary/40" key={label} type="button">
              <span className="grid size-9 place-items-center rounded-lg bg-accent-primary/10 text-accent-primary">
                <SettingsIcon className="size-4" name="download" />
              </span>
              <span>
                <span className="block text-sm font-semibold text-text-heading">{label}</span>
                <span className="block text-xs text-text-muted-v2">{desc}</span>
              </span>
            </button>
          ))}
        </div>
      </Subsection>

      <Subsection title="Backup automático">
        <SettingRow description="Salvar snapshot diário dos dados" label="Backup automático">
          <ToggleSwitch checked onChange={() => {}} />
        </SettingRow>
        <SettingRow description="Com que frequência o backup é realizado" label="Frequência">
          <select className={inputClass} defaultValue="daily">
            <option value="daily">Diário (00h)</option>
            <option value="12h">A cada 12h</option>
            <option value="weekly">Semanal</option>
          </select>
        </SettingRow>
        <SettingRow description="30/03/2026 às 00:15" label="Último backup">
          <button className="h-9 rounded-sm border border-border-default-v2 bg-surface-card-hover px-3 text-sm font-semibold text-text-body" type="button">Baixar</button>
        </SettingRow>
      </Subsection>
    </SectionFrame>
  )
}

function SectionFrame({ children, description, title }) {
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-lg font-bold text-text-heading">{title}</h2>
        <p className="mt-1 text-sm text-text-muted-v2">{description}</p>
      </div>
      <div className="space-y-6">{children}</div>
    </div>
  )
}

function Subsection({ children, title }) {
  return (
    <div>
      <p className="mb-3 text-xs font-semibold uppercase tracking-[0.12em] text-text-muted-v2">{title}</p>
      <SettingsGroup>{children}</SettingsGroup>
    </div>
  )
}

function SettingsGroup({ children }) {
  return <div className="rounded-xl border border-[var(--border-default)] bg-[var(--surface-elevated)] px-6">{children}</div>
}

function ToggleRow({ checked, description, label, onChange }) {
  return (
    <SettingRow description={description} label={label}>
      <Switch checked={checked} onCheckedChange={onChange} />
    </SettingRow>
  )
}

function SettingRow({ children, description, label }) {
  return (
    <div className="flex items-center justify-between gap-6 border-b border-[var(--border-default)] py-4 last:border-0">
      <div className="min-w-0 flex-1 pr-4">
        <p className="text-sm font-semibold text-[var(--text-primary)]">{label}</p>
        {description ? <p className="mt-1 text-xs leading-5 text-[var(--text-muted)]">{description}</p> : null}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  )
}

function ToggleSwitch({ checked, onChange }) {
  return (
    <button
      aria-checked={checked}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${checked ? 'bg-accent-primary' : 'bg-surface-card-hover'}`}
      onClick={() => onChange(!checked)}
      role="switch"
      type="button"
    >
      <span className={`inline-block size-4 rounded-full bg-white shadow-md transition-transform ${checked ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
  )
}

function SettingsIcon({ className = 'size-4', name }) {
  const common = {
    className,
    fill: 'none',
    stroke: 'currentColor',
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    strokeWidth: 1.9,
    viewBox: '0 0 24 24',
  }

  if (name === 'shield') return <svg {...common}><path d="M12 3 5 6v5c0 4 3 7.5 7 10 4-2.5 7-6 7-10V6l-7-3Z" /></svg>
  if (name === 'database') return <svg {...common}><ellipse cx="12" cy="5" rx="7" ry="3" /><path d="M5 5v14c0 1.7 3.1 3 7 3s7-1.3 7-3V5M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3" /></svg>
  if (name === 'download') return <svg {...common}><path d="M12 3v12M7 10l5 5 5-5M5 21h14" /></svg>
  if (name === 'bell') return <svg {...common}><path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></svg>
  if (name === 'user') return <svg {...common}><path d="M20 21a8 8 0 0 0-16 0" /><circle cx="12" cy="7" r="4" /></svg>
  if (name === 'plug') return <svg {...common}><path d="M9 7V3M15 7V3M7 11h10M8 7h8v5a4 4 0 0 1-8 0V7ZM12 16v5" /></svg>
  if (name === 'alert') return <svg {...common}><path d="M12 3 2 21h20L12 3Z" /><path d="M12 9v5M12 18h.01" /></svg>

  return <svg {...common}><path d="M12 3v3M12 18v3M4.9 4.9 7 7M17 17l2.1 2.1M3 12h3M18 12h3M4.9 19.1 7 17M17 7l2.1-2.1" /><circle cx="12" cy="12" r="3" /></svg>
}
